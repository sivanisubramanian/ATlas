# ATlas — Athletic Training Learning System

## Publish on Netlify (quickest)
1. Go to app.netlify.com/drop
2. Drag and drop this entire folder
3. Live instantly
